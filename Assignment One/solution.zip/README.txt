1. Unzip the "housing_train.zip" folder, keeping the .py files inside the
	 solution folder and the data sets outside of it. 
2. cd into the solution folder.
3. use the command "python part_1.py" to test part one of the assignment.
4. use the command "python part_2.py" to test part two of the assignment.
5. To test part two without regularization. Edit part_2.py, and set MyLamda to 0.0